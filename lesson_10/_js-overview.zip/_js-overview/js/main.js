var userFullName = "This is variable",
	numberVar1 = 45,
	numberVar2 = 54,
	checked = true,
	unchecked = false,
	nothing = null,
	notDefined,
	notANumber = NaN;

// console.log(numberVar2 > numberVar1);
// console.log(numberVar2 < numberVar1);
// console.log(numberVar2 <= numberVar1);
// console.log(numberVar2 >= numberVar1);
// console.log(numberVar2 != numberVar1);
// console.log(false === 0);
// console.log(numberVar2++);
// console.log(numberVar2);
// console.log(numberVar2--);
// console.log(--numberVar2);
// console.log(++numberVar2);


// var userName = prompt("Enter your name");

// if (userName == "admin") {
// 	alert("hello admin");
// } else {
// 	alert("Good bye, " + userName + "!");
// };



// var array = [1, 2, 3, 4];

// console.log(array);

// array.length = 10;

// array[10] = 5;

// console.log(array);
// console.log(array.length);


var array = [1, 'text', 3, 'ololol'];

for (var i = 0; i < array.length; i++) {
	// console.log('i = ' + i);
	// console.dir('array[i] = ' + array[i]);
	// console.log('end of cycle');
}


var newString = 'some text';

// console.log(newString.length);



var array = [1, 2, 3];
var object = {
	'firstElement': 1,
	'second': 2,
	5: 3
};



var human = {
	age: numberVar1,
	firstName: 'Vasya',
	lastName: 'Pupkin'
};

// console.log(object['firstElement']);

human['newAge'] = numberVar1;
human.newAge = numberVar1;

// console.dir( human );


var human = {
	age: numberVar1,
	firstName: 'Vasya',
	lastName: 'Pupkin'
};

// for (var key in human){
// 	console.log('key ' + key);
// 	console.log('human[key] ' + human[key]);
// };

// for (var key in array){
// 	console.log('key ' + key);
// 	console.log('array[key] ' + array[key]);
// }

var name = 'GlobalFirstName';
var a = 1;

function sayHello() {
	var a = 2;


	function alertHello(){
		var a = 3;
		console.log("alertHello: ", a);
	};

	console.log("SayHello1: ", a);
	alertHello();
};

console.log("global a: ", a);
sayHello();



















